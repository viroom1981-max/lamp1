import os
import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardMarkup, InlineKeyboardButton
)

TOKEN = os.getenv("TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))
CATALOG_URL = os.getenv("CATALOG_URL")

bot = Bot(token=TOKEN)
dp = Dispatcher()

catalog_items = [
    {
        "name": "Лампа S",
        "photo": "https://i.imgur.com/abcd123.jpg",
        "desc": "Компактная лампа, идеально для стола.",
        "size": "S"
    },
    {
        "name": "Лампа M",
        "photo": "https://i.imgur.com/efgh456.jpg",
        "desc": "Средний размер, универсальный вариант.",
        "size": "M"
    },
    {
        "name": "Лампа L",
        "photo": "https://i.imgur.com/ijkl789.jpg",
        "desc": "Большая лампа, эффектный интерьер.",
        "size": "L"
    }
]

sizes = ["S", "M", "L", "Свой размер"]

kb_main = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Каталог")],
        [KeyboardButton(text="Выбрать размер")],
        [KeyboardButton(text="Связаться с мастером")],
        [KeyboardButton(text="Мои заявки")]
    ],
    resize_keyboard=True
)

kb_sizes = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text=s) for s in sizes]],
    resize_keyboard=True
)

catalog_button = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="📸 Каталог ламп", url=CATALOG_URL)]
    ]
)

orders = {}
user_state = {}


@dp.message()
async def handler(message: types.Message):
    user_id = message.from_user.id
    text = message.text

    if text == "/start":
        await message.answer("Добро пожаловать!", reply_markup=kb_main)
        await message.answer("Готовые работы:", reply_markup=catalog_button)
        return

    if text == "Каталог":
        for item in catalog_items:
            kb = InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text="Заказать эту лампу", callback_data=f"order_{item['size']}")]
                ]
            )
            await message.answer_photo(
                photo=item["photo"],
                caption=f"{item['name']}\n\n{item['desc']}",
                reply_markup=kb
            )
        return

    if text == "Выбрать размер":
        await message.answer("Выбери размер:", reply_markup=kb_sizes)
        return

    if text in sizes[:-1]:
        orders.setdefault(user_id, []).append({"size": text})
        await bot.send_message(
            ADMIN_ID,
            f"Новая заявка!\nРазмер: {text}\nОт: @{message.from_user.username}"
        )
        await message.answer("Спасибо! Я передал мастеру.", reply_markup=catalog_button)
        return

    if text == "Свой размер":
        user_state[user_id] = {"step": "height"}
        await message.answer("Введи высоту (см):")
        return

    if user_state.get(user_id, {}).get("step") == "height":
        if not text.isdigit():
            await message.answer("Напиши число.")
            return
        user_state[user_id]["height"] = int(text)
        user_state[user_id]["step"] = "diameter"
        await message.answer("Теперь введи диаметр (см):")
        return

    if user_state.get(user_id, {}).get("step") == "diameter":
        if not text.isdigit():
            await message.answer("Напиши число.")
            return

        height = user_state[user_id]["height"]
        diameter = int(text)

        orders.setdefault(user_id, []).append(
            {"size": "custom", "height": height, "diameter": diameter}
        )

        await bot.send_message(
            ADMIN_ID,
            f"Кастомная заявка!\nВысота: {height} см\nДиаметр: {diameter} см\nОт: @{message.from_user.username}"
        )

        user_state.pop(user_id, None)

        await message.answer("Спасибо! Я передал мастеру.", reply_markup=catalog_button)
        return

    if text == "Связаться с мастером":
        await message.answer("Пиши сюда: @ТВОЙ_ЮЗЕРНЕЙМ")
        return

    if text == "Мои заявки":
        user_orders = orders.get(user_id, [])
        if not user_orders:
            await message.answer("У тебя пока нет заявок.")
            return

        msg = "Твои заявки:\n\n"
        for o in user_orders:
            if o["size"] != "custom":
                msg += f"• Размер: {o['size']}\n"
            else:
                msg += f"• Кастом: {o['height']}×{o['diameter']} см\n"

        await message.answer(msg)
        return


@dp.callback_query()
async def callbacks(call: types.CallbackQuery):
    data = call.data

    if data.startswith("order_"):
        size = data.split("_")[1]

        orders.setdefault(call.from_user.id, []).append({"size": size})

        await bot.send_message(
            ADMIN_ID,
            f"Заявка из каталога!\nРазмер: {size}\nОт: @{call.from_user.username}"
        )

        await call.message.answer("Спасибо! Я передал мастеру.")
        await call.answer()


async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
